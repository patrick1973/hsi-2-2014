#include <stdio.h>
#include <stdlib.h>

#include "integer_file.h"

#define MY_FILE "integer_file.txt"

int main(int argc, char** argv)
{
    // TODO: implement

    return 0;
}
