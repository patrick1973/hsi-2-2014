#pragma once

unsigned int MakeBitmask(unsigned int width, unsigned int shift);
unsigned int CountOnes(unsigned int value);
