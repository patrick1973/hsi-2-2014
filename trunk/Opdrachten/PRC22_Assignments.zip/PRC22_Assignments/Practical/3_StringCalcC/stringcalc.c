#include "stringcalc.h"

extern int Add(char* numbers)
{
    int Sum = 0;
    return Sum;
}
