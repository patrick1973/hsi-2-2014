#ifndef _STRINGCALC_H
#define _STRINGCALC_H

extern int Add(char* numbers);

#endif
