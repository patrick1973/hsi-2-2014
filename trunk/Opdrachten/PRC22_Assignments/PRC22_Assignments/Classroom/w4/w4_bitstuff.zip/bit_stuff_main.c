#include <stdio.h>

#include "bit_stuff.h"

int main(int argc, char** argv)
{
    // TODO: implement if you want
    return 0;
}
