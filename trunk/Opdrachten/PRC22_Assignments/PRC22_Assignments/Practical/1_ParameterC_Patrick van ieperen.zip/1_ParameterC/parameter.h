#ifndef PARAMETER_H_INCLUDED
#define PARAMETER_H_INCLUDED


// odracht B
void SwapValues (int *a, int *b);

//odracht c
void SwapAddresses(int **a, int **b);

//opdracht d
int GetSumReturn(int Arr[], int n);

//opdracht e
void GetSumParameter (int *Arr,int n, int *Sum);

//opdracht f
char *Dutch (int i);
void Translate(char *Language(int Index),int Arr[], int n, char **Translations);
 
#endif // PARAMETER_H_INCLUDED
